import { Component } from '@angular/core';

@Component({
  selector: 'app-add-committee',
  standalone: true,
  imports: [],
  templateUrl: './add-committee.component.html',
  styleUrl: './add-committee.component.scss'
})
export class AddCommitteeComponent {

}
